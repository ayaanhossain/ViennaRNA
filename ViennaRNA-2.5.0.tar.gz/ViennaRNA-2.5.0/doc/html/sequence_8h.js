var sequence_8h =
[
    [ "vrna_seq_t", "group__alphabet__utils.html#gaa35bee3061759495467070b47d0e1f22", null ],
    [ "vrna_seq_type_e", "group__alphabet__utils.html#ga85cda3fcf5d6bd7ec090d3a96e808609", [
      [ "VRNA_SEQ_UNKNOWN", "group__alphabet__utils.html#gga85cda3fcf5d6bd7ec090d3a96e808609ad8682ac290d0dd51022e3b82840e1a74", null ],
      [ "VRNA_SEQ_RNA", "group__alphabet__utils.html#gga85cda3fcf5d6bd7ec090d3a96e808609ac52309234beaf94e6a3bd1b9b69de9f4", null ],
      [ "VRNA_SEQ_DNA", "group__alphabet__utils.html#gga85cda3fcf5d6bd7ec090d3a96e808609a4da1613644c3a3766ef1d6494f271332", null ]
    ] ]
];