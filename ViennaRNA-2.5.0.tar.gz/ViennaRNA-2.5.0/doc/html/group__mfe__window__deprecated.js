var group__mfe__window__deprecated =
[
    [ "Lfold.h", "Lfold_8h.html", null ],
    [ "Lfold", "group__mfe__window__deprecated.html#gafdd1e11b5c7ad443b9f86b818e67bab4", null ],
    [ "Lfoldz", "group__mfe__window__deprecated.html#ga9b568887c6091a54252729adcb35f6d2", null ]
];