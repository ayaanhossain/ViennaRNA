var group__buffer__utils =
[
    [ "char_stream.h", "datastructures_2char__stream_8h.html", null ],
    [ "stream_output.h", "datastructures_2stream__output_8h.html", null ],
    [ "vrna_ostream_t", "group__buffer__utils.html#ga8da189552af21ab6e4e88bdcc240870c", null ],
    [ "vrna_callback_stream_output", "group__buffer__utils.html#ga4adb94338a6f0a1a451e03c1bdac0d9d", null ],
    [ "vrna_cstr", "group__buffer__utils.html#gadb2818f368e10a3b60a96bb3c80228d2", null ],
    [ "vrna_cstr_discard", "group__buffer__utils.html#gacf6e3934e61bea12bdc38a8f97b0c75d", null ],
    [ "vrna_cstr_free", "group__buffer__utils.html#ga7ec48ec280f699928c70428cc245dc77", null ],
    [ "vrna_cstr_close", "group__buffer__utils.html#ga5a3f6a0a73b3d2d38fe011cdaed0ad28", null ],
    [ "vrna_cstr_fflush", "group__buffer__utils.html#gab59ad4781f7de960bdd1af5b1965c94b", null ],
    [ "vrna_ostream_init", "group__buffer__utils.html#gad23113e66a0910ec2341856e2da56bf6", null ],
    [ "vrna_ostream_free", "group__buffer__utils.html#gaf813ec90e1446ba82c89f9a39688a3b3", null ],
    [ "vrna_ostream_request", "group__buffer__utils.html#gaebca91932705d71bcbf00bd8d82bd7c8", null ],
    [ "vrna_ostream_provide", "group__buffer__utils.html#ga6253c42abdeaf3b41a38204865e1f0f7", null ]
];